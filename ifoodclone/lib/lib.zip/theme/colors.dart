import 'package:flutter/material.dart';

var primary = const Color(0xFF00954d);
var white = const Color(0xFFFFFFFF);
var bgColor = const Color(0xFFf0f1f3);
var black = const Color(0xFF000000);
var textFieldColor = Colors.grey.withOpacity(0.15);
var yellowStar = const Color(0xFFfacb00);
