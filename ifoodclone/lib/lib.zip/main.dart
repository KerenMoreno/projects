import 'package:flutter/material.dart';
import 'package:ifoodclone/pages/root_app.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: RootApp(),
  ));
}
